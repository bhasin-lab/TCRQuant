<div class="fixed-header">

	<div class="header-bottom">
		<div class="container">
			<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				 <div class="logo">
						<a class="navbar-brand" href="index.php"><img src="images/tcrquant_logo.png" alt="logo" style="img-responsive img-fluid" width=100 height=80></a>
					</div>
				</div>
				<br>
				<br>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<nav class="cl-effect-1" id="cl-effect-1">
						<ul class="nav navbar-nav">
							<?php
                                                                // Define each name associated with an URL
                                                                $urls = array(
                                                                        'Home' => './index.php',
                                                                        'Team' => './team.php',
                                                                        'Analyze' => './main_tool.php',
                                                                        'Jobs' => './jobid.php',
                                                                        'Login' => './login.php'

                                                                        );

                                                        foreach ($urls as $name => $url) {
                                                        print '<li '.(($currentPage === $name) ? ' class="active" ': '').
                                                          '><a href="'.$url.'">'.$name.'</a></li>';
                                                                }
                                                        ?>

						</ul>
					</nav>
				</div>

				<!-- /.navbar-collapse -->
			</nav>

		</div>

	</div>
</div>
