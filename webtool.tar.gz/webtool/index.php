<?php
  session_start();
	if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You are not logged in";
  	}
  	if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  }
?>

<!DOCTYPE html>
<html>
<head>
<title>TcrQuant</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Domicile Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/ken-burns.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/animate.min.css" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>

<body>
<!-- header -->
<?php $currentPage = 'Home'; ?>
<?php include 'header.php';?>
<!-- //header -->
<br>
<!-- banner -->
<div class="col-md-7 agileits_about_bottom_left">
<?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
	<?php endif ?>
<?php  if (!isset($_SESSION['username'])) : ?>
    	<p>You are not logged in</p>
    <?php endif ?>
</div>
<!-- //banner -->
<!-- about-bottom -->
	<div class="about-bottom">
			<div class="col-md-7 agileits_about_bottom_left">
				<h3>About the TOOL</h3>
				<p align="justify">
We have developed a fully automated pipeline to analyse both bulk as well as single cell targated TCR sequence data in order to extract Complementarity-determining region CDR3 in both Alpha and Beta chain of the receptor and further analyse the obtained CDR3 Sequences in terms of exploring their diversity in a repertoire, their relative expression and its change in a group of samples, set of co-expressed cdr3 clonotypes, relative change of top proportional clones, etc. The tool accepts both bulk as well as single-cell targeted sequence data in raw compressed fastq format and has an option of running the QC analysis on raw data to check their quality. At Present Human and Mouse data are supported. For bulk sequence data it has an option of filtering out the clonotypes and keeping only the sequences which are highly positvely correlated between the two chains.<br><br><br><br></p>

				<div class="clearfix"> </div>

			</div>
			<div class="col-md-5 agileits_about_bottom_right">
				<img src="images/tcrworkflow.png" alt=" " class="img-responsive img-fluid"/>
			</div>
			<div class="clearfix"> </div>
	</div>
<!-- //about-bottom -->

<br>


<!-- footer -->
	<?php include 'footer.php';?>
	<!----footer--->

</body>
</html>
