<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: ./login.php');
  }

  if ($_SESSION['status'] == 'inactive') {
        $_SESSION['message'] = "You must activate your account first. Click on the activation link sent in your email to activate your accout";
        header('location: ./login.php');
  }

  $usr = $_SESSION['username'];
  $db2 = mysqli_connect('localhost', 'root', '123456', 'registration');
  $query3 = "SELECT DISTINCT jobid FROM jobs WHERE username='$usr'";
  $result = mysqli_query($db2, $query3);
  $rshow = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>
<head>
<title>TcrQuant</title><!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Domicile Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
                function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
        jQuery(document).ready(function($) {
                $(".scroll").click(function(event){
                        event.preventDefault();
                        $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
                });
        });
</script>
<!-- start-smoth-scrolling -->
</head>

<style>
        .box {
        border: 1px solid black;
        padding: 50px;
        margin: 20px;
        -webkit-box-shadow: 3px 3px 5px 6px #808080;  /* Safari 3-4, iOS 4.0.2 - 4.2, Android 2.3+ */
        -moz-box-shadow: 3px 3px 5px 6px #808080;  /* Firefox 3.5 - 3.6 */
        box-shadow: 3px 3px 5px 6px #808080;  /* Opera 10.5, IE 9, Firefox 4+, Chrome 6+, iOS 5 */
        }

	input[type=submit]{
        background-color: #FF9933;
        border: none;
        color: white;
        padding: 8px 16px;
        text-decoration: none;
        margin: 4px 2px;
        cursor: pointer;
        }

        </style>

<body>
<!-- header -->
        <?php $currentPage = 'Jobs'; ?>
        <?php include 'header.php';?>
	<br>
<!-- //header -->
<br>
<!-- service-breadcrumb -->
        <div class="service-breadcrumb">
                <div class="container">
                        <div class="wthree_service_breadcrumb_left">
                                <ul>
                                        <li><a href="./index.php">Home</a><i>|</i></li>
                                        <li>Jobs</li>
                                </ul>
				 <?php  if (isset($_SESSION['username'])) : ?>
                                <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
                                <p> <a href="./index.php?logout='1'" style="color: red;">logout</a> </p>
                                <?php endif ?>
                        </div>
                        <div class="wthree_service_breadcrumb_right">
                                <h3>Submitted Jobs</h3>
                        </div>
                        <div class="clearfix"> </div>
                </div>
        </div>
<!-- //service-breadcrumb -->

	<div align="center">
	<br>
	<h3>Your JOBS</h3>
	<?php print_r($rshow['jobid']); ?>
	<br>
	<h3>Check Output by jobID</h3>
        <form action="./show_output.php" method="post">
        <p>Specify JobID:</p><input type="text" name="output">
        <input type="Submit" value="submit">
        </form>
	</div>
	<br>
	<!-- footer -->
        <?php include 'footer.php';?>

        <!-- footer--->

  </body>
</html>
