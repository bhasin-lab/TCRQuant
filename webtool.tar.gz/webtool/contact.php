
<!DOCTYPE html>
<html>
<head>
<title>TcrQuant</title><!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Domicile Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>
<!----header-------->
<?php $currentPage = 'Contact'; ?>
<?php include 'header.php';?>

<!-- //header -->
<!-- service-breadcrumb -->
	<div class="service-breadcrumb">
		<div class="container">
			<div class="wthree_service_breadcrumb_left">
				<ul>
					<li><a href="index.html">Home</a><i>|</i></li>
					<li>Contact Us</li>
				</ul>
			</div>
			<div class="wthree_service_breadcrumb_right">
				<h3>Contact Us</h3>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //service-breadcrumb -->

<!-- mail -->
	<div class="mail">
		<div class="container">
			<h3>Contact Us</h3>

			<div class="agileits_mail_grids">
				<div class="col-md-6 agileits_mail_grid_left">
					<form action="#" method="post">
						<h4>Your Name*</h4>
						<input type="text" name="Name" value="Name" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Name';}" required="">
						<h4>Your Email*</h4>
						<input type="email" name="Email" value="Email" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Email';}" required="">
						<h4>Your Phone Number*</h4>
						<input type="text" name="Phone" value="Phone" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Phone';}" required="">
						<h4>Your Message*</h4>
						<textarea name="Message" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Message...';}" required="">Message...</textarea>
					</form>
				</div>
				<div class="col-md-6 agileits_mail_grid_left">
					<div class="agileits_mail_grid_left_grid">
						<h4>Contact Info</h4>
						<ul class="contact_info">
							<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Beth Israel Deaconess Medical Center Research North Building 99, Brookline Ave
Boston, MA, 02215</span></li>
							<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@satyahomes.com">info@tcrquant.com</a></li>
							<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+1 0000000000</li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //mail -->

<!-- map -->
	<div class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5897.9378304377105!2d-71.10680597339291!3d42.34318609670305!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e379f65efc4e43%3A0x5b80872c0c36359d!2sBeth+Israel+Deaconess+Medical+Center+Research+North!5e0!3m2!1sen!2sin!4v1565598383472!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
<!-- //map -->
<!-- footer -->

	<?php include 'footer.php';?>

<!-- //footer -->

</body>
</html>
