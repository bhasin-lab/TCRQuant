<html>
  <head>

    <title>output-page</title>

  </head>
  <body>

    <h2>Submitted Jobs</h2>

    <hr>
    <?php
	$jobid = $_POST["output"];
	$jobpath = './raw/' . $jobid;
	if (is_dir($jobpath)){

		$filepath = $jobpath . '/tcr_main.html';
		$log = $jobpath . '/';
		if (file_exists($filepath)){
			 echo "<a href=",$filepath,">",FinalReport,"</a>","<br>";
		}
		else{
			echo "JobID ", $jobid," found but output file does not exist. Job may either still be running or an error might have occured","<br>";
		}
	}
	else{
		echo "JobID ", $jobid," not found","<br>";
	}
    ?>

    <hr>
    <input type="button" onclick="window.location='http://bhasinlab.us/tcr_page/jobid.php'" class="Redirect" value="Click Here To Redirect"/>

  </body>
</html>

