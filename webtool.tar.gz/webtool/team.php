<!DOCTYPE html>
<html>
<head>
<title>TcrQuant</title><!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Domicile Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js 
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>

<body>
<!-- header -->
	<?php $currentPage = 'Team'; ?>
	<?php include 'header.php';?>
	<br>
<!-- //header -->
<br>
<!-- service-breadcrumb -->
	<div class="service-breadcrumb">
		<div class="container">
			<div class="wthree_service_breadcrumb_left">
				<ul>
					<li><a href="./index.php">Home</a><i>|</i></li>
					<li>Team</li>
				</ul>
			</div>
			<div class="wthree_service_breadcrumb_right">
				<h3>Research Team</h3>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //service-breadcrumb -->

<!-- team -->
	<div class="team">
		<div class="container">
			<h3>Research Team</h3>
			<p class="dolor">Meet the team behind the development of this tool</p>
			<div class="wthree_team_grids">
                                <div class="col-md-3 wthree_team_grid">
                                        <div class="wthree_team_grid1">
                                                <div class="hover14 column">
                                                        <div>
                                                                <figure><img src="images/rpanchal.jpg" alt=" " class="img-responsive" /></figure>
                                                        <br>
							</div>
                                                </div>
						<br>
                                                <div class="wthree_team_grid1_pos">
                                                        <h4>Ruchit Panchal</h4>
                                                </div>
                                        </div>
                                        <div class="wthree_team_grid2">
                                                <ul class="social-icons">
                                                        <li><a href="#" class="icon icon-border linkedin"></a></li>
						</ul>
                                        </div>
                                </div>


				<div class="col-md-3 wthree_team_grid">
					<div class="wthree_team_grid1">
						<div class="hover14 column">
							<div>
								<figure><img src="images/mbhasin.jpg" alt=" " class="img-responsive" /></figure>
							<br>
							</div>
						</div>
						<br>
						<div class="wthree_team_grid1_pos">
							<h4>Manoj Bhasin</h4>
						</div>
					</div>

				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //team -->
<!-- footer -->
	<?php include 'footer.php';?>
	<!-- footer--->
</body>
</html>
