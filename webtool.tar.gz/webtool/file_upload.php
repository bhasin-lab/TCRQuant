
<?php
    session_start();
    if($_POST['job']=="random"){
   	do {
   		$temp = mt_rand(1,10000);
    		$uploaddir = './raw/' . $temp;
    	} while(is_dir($uploaddir));
    }
    if($_POST['job']=="user"){
    	$temp = $_POST['userid'];
    	$uploaddir = './raw/' . $temp;
	if(is_dir($uploaddir)){
		$_SESSION['error'] = "jobid already in use. please provide another.";
		exit;
	}
    }
    $oldmask = umask(0);
    mkdir($uploaddir,0777);
    umask($oldmask);
    $_SESSION['temp'] = $temp;
    $_SESSION['tempA'] = $uploaddir;
    //$_SESSION['tempB'] = $srcdir;

   if(isset($_FILES['userfile'])){
      $errors = "";
      $_SESSION['error'] = $errors;
      $file_name = $_FILES['userfile']['name'];
      $file_type = $_FILES['userfile']['type'];
      //print($file_name);
      $file_ext = strtolower(end(explode('.',$file_name)));

      $extensions= array("fastq.gz");

      //if(in_array($file_ext,$extensions)==false){
         //$errors = "extension not allowed, please choose a fastq.gz file.";
	 //$_SESSION['error'] = $file_ext;
      //}

      if($errors==""){
         // Count # of uploaded files in array
	 $total = count($_FILES['userfile']['name']);
	 // Loop through each file
	 for( $i=0 ; $i < $total ; $i++ ) {
	    //Get the temp file path
  	    $tmpFilePath = $_FILES['userfile']['tmp_name'][$i];

	    //Make sure we have a file path
  	    if ($tmpFilePath != ""){
    	       //Setup our new file path
    	       $newFilePath = $uploaddir . '/' . $_FILES['userfile']['name'][$i];

	       //Upload the file into the temp dir
    	       if(move_uploaded_file($tmpFilePath, $newFilePath)) {

            	   //move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);
            	   //create_progress();
            	   //print($_FILES['userfile']['name'][$i]);

            	   echo "<br>";

      	    	   }
      	     }
      	   }
       }
       else{
          print_r($errors);
       }
       echo "Success \r\n";
       echo "Redirecting...";
    }
    else{
      $_SESSION['error'] = "No File Detected";
    }
    header("Location: http://bhasinlab.us/tcr_page/main_tool.php");
?>
