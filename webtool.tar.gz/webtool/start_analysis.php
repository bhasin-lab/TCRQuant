<html>
  <head>

    <title>Analysis-page2</title>

  </head>
  <body>

    <h2>Starting Analysis</h2>

    <hr>


      <input type="button" onclick="window.location='http://bhasinlab.us/tcr_page/index.php'" class="Redirect" value="Click Here To Redirect"/>


    <h3>Please wait: data processing...</h3>
    <?php
    	session_start();
	set_time_limit(0);
	ob_implicit_flush(true);
	ob_end_flush();
	$sp = $_POST["species"];
	$jobid = $_SESSION['tempA'];
	$down = $_POST["downsample"];
	$filter = $_POST["filter"];
	$usr = $_SESSION['username'];
	$jb = $_SESSION['temp'];

	$db2 = mysqli_connect('localhost', 'root', '123456', 'registration');
	$query2 = "INSERT INTO jobs (username, jobid) VALUES('$usr', '$jb')";
	mysqli_query($db2, $query2);

	echo "<h4>Your JobID is : ", $jb, "<h4><br>";

	if ($down == "other"){

		$down = $_POST["custom"];
	}

	//echo $sp;
	echo "<br>";

	$cmd = "nohup bash /home/ubuntu/rpanchal/tcr_pipeline/tcr_pipeline.sh " . $sp . " " . $jobid . " " . $down;

	$descriptorspec = array(
   	0 => array("pipe", "r"),   // stdin is a pipe that the child will read from
   	1 => array("pipe", "w"),   // stdout is a pipe that the child will write to
   	2 => array("pipe", "w")    // stderr is a pipe that the child will write to
	);
	flush();
	$process = proc_open($cmd, $descriptorspec, $pipes, realpath('./'), array());
	echo "<pre>";
	if (is_resource($process)) {
    		while ($s = fgets($pipes[1])) {
        		print $s;
        		flush();
    		}
	}
	echo "</pre>";
	proc_close($process);
    ?>

    <hr>

    <?php

    	$cmd2 = "nohup bash /home/ubuntu/rpanchal/tcr_pipeline/ranalysis.sh " . $jobid . " " . $filter;
	echo "Starting with Repertoire Diversity analysis...";
	flush();
	$process2 = proc_open($cmd2, $descriptorspec, $pipes, realpath('./'), array());
	echo "<pre>";
	if (is_resource($process2)) {
    		while ($s = fgets($pipes[2])) {
        		print $s;
        		flush();
    		}
	}
	echo "</pre>";
	proc_close($process2);
	echo "All analysis done: Please click to see the output";
	echo "<br>";
	echo "<p>","View Output","</p>","<br>";
	echo "<a href=",$jobid . "/tcr_main.html",">",output,"</a>","<br>";

    ?>

    <hr>

    <input type="button" onclick="window.location='http://bhasinlab.us/tcr_page/index.php'" class="Redirect" value="Click Here To Redirect"/>

  </body>
</html>
