<div class="footer">
		<div class="container">
			<div class="w3agile_footer_grids">
				<div class="col-md-4 agileinfo_footer_grid">
					<div class="footer-logo">
						<h3><a class="navbar-brand" href="index.php">TcRQuant</a></h3>
					</div>
				</div>
				<div class="col-md-3 agileinfo_footer_grid">
				<h3> Address</h3>
					<p>Beth Israel Deaconess Medical Center<br>
					Research North Building<br>99, Brookline Ave<br>Boston, MA, 02215<br></p>

				</div>

				<div class="col-md-5 agileinfo_footer_grid">
					<div class="agileinfo_footer_grid_left">
						<a href="#"><img src="images/hms_bi_logo.png" alt=" " class="img-responsive"/> </a>
					</div>

					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="footer-copy">
		<div class="container">
			<p>&copy; 2019 TcrQuant. All rights reserved
		</div>
	</div>

	<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->
