<?php
session_start();

// connect to the database
$db = mysqli_connect('localhost', 'root', '123456', 'registration');

if(!empty($_GET["id2"])) {
	$query = "UPDATE users SET status='active' WHERE id2='" . $_GET["id2"]. "'";
	$result = mysqli_query($db, $query);
	if(!empty($result)) {
		$_SESSION['message'] = "Your account is activated.";
	} else {
		$_SESSION['message'] = "Problem in account activation.";
	}
}

header('location: ./login.php');

?>
